#!/bin/sh
ls "$@"
